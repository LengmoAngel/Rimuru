# comp_basic

## 实验过程

+ 初始化 comp 实例，配置输出滤波器，输出是否翻转，比较器输出不定向到任何定时，配置正向输入通道和反向输入通道连接的引脚，设置高速比较模式。
+ 使能 comp 实例。
+ 主函数中，用户根据提示向串口输入任意字符，串口打印输出比较器COMP的正向输入通道1与反相输入通道0输入电压比较情况。

## 实验结果

COMP Basic.
Press any key to get compare result.
Positive Input Higher.
Positive Input Higher.
